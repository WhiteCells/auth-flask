#pragma once
#pragma once

// Note: Update the version when release a new version.

// ORMPP_VERSION % 100 is the sub-minor version
// ORMPP_VERSION / 100 % 1000 is the minor version
// ORMPP_VERSION / 100000 is the major version
#define ORMPP_VERSION 13  // 0.1.3
